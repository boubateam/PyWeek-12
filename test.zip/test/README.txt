Ninth Kind
==========

Entry in PyWeek #12 <http://www.pyweek.org/12/>
Team: Bouba Team
Members: ahsio, cyqui, gleuh, greg0ire, joksnet, tocab, TOTOleHero



DEPENDENCIES:

You might need to install some of these before running the game:

  Python:     http://www.python.org/
  PyGame:     http://www.pygame.org/



RUNNING THE GAME:

On Windows or Mac OS X, locate the "run_game.pyw" file and double-click it.

Othewise open a terminal / console and "cd" to the game directory and run:

  python run_game.py



HOW TO PLAY THE GAME:

At the top of the screen the monster attacks you.

First he drops one sound.
You must block this attack by recreating the exact same sound 
by clicking on the band with the same color

Then he drops the first sound plus one more. You must block the two sounds.
And so on up to nine sound attacks.

At the end if you have replayed all the nine sounds,
you win and are allowed to go to the next level.


LICENSE:

This game (Ninth Kind) is under the terms of the WTFPL license. View COPYING
for more information.
